Welcome to toypandas's documentation!
=====================================
A library for educational purposes to simplify the syntax and notional machine of Python Pandas 


Installation
============
``$ pip install toypandas``



Contents
========

.. toctree::
   :maxdepth: 4


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
