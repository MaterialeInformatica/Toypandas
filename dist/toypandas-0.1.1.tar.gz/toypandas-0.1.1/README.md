# ToyPandas
A library for educational purposes to simplify the syntax and notional machine of Python Pandas 
